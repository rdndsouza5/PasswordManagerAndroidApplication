package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class deletepass extends AppCompatActivity {
Button delpass;
EditText dweb;
Intent homm,ran,del,ret,urown;
DBhelper dBhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deletepass);
        delpass=findViewById(R.id.delpass);
        dweb=findViewById(R.id.dweb);
        dBhelper=new DBhelper(this);
        delpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String website = dweb.getText().toString().toLowerCase(Locale.ROOT);
                if(dweb.getText().toString().equals(""))
                    Toast.makeText(deletepass.this, "Please enter the website", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkudeletedata = dBhelper.deleteuserdata(website);
                    if (checkudeletedata == true)
                        Toast.makeText(deletepass.this, "All password for "+website+" deleted", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(deletepass.this, "Website "+website+" doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenufromdelete,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.rando) {
            ran=new Intent(deletepass.this,random.class);
            startActivity(ran);
        }
        if(id==R.id.hom)
        {
            homm=new Intent(deletepass.this,MainActivity.class);
            startActivity(homm);
        }
        if(id==R.id.retreiv)
        {
            ret=new Intent(deletepass.this,retreivepass.class);
            startActivity(ret);
        }

        if(id==R.id.retreiv)
        {
            ret=new Intent(deletepass.this,retreivepass.class);
            startActivity(ret);
        }
        if(id==R.id.updat)
        {
            Intent upda=new Intent(deletepass.this,updatepass.class);
            startActivity(upda);
        }
        if(id==R.id.viewa) {
            Intent vie=new Intent(deletepass.this,viewallpass.class);
            startActivity(vie);
        }
        return super.onOptionsItemSelected(item);
    }
}