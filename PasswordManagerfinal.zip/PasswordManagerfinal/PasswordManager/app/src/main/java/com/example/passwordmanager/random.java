package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class random extends AppCompatActivity {
    Button generatepass,savepass;
    TextView pass;
    EditText web;
    String passs="null";
    Intent homm,gen,del,ret;
    DBhelper dBhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random);
        web=findViewById(R.id.web);
        pass=findViewById(R.id.pass);
        pass.setTextIsSelectable(true);
        generatepass=findViewById(R.id.generatepass);
        dBhelper=new DBhelper(this);
        savepass=findViewById(R.id.savepass);
        generatepass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
                String specialCharacters = "!@#$%^&*?";
                String numbers = "1234567890";
                String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
                Random random = new Random();
                char[] password = new char[20];
                password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
                password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
                password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
                password[3] = numbers.charAt(random.nextInt(numbers.length()));

                for(int i = 4; i< 20 ; i++) {
                    password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
                }
                 passs = String.valueOf(password);
                pass.setText(passs);
            }
        });
        savepass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count=0;
                if(web.getText().toString().equals("")||passs.equals("null"))
                    Toast.makeText(random.this, "Please enter website or click on generate password", Toast.LENGTH_SHORT).show();
                else {
                    String website = web.getText().toString().toLowerCase(Locale.ROOT);
                    Cursor res = dBhelper.getdata();
                    if (res.getCount() == 0) {
                    }
                    while (res.moveToNext()) {
                        String test = res.getString(0).toLowerCase(Locale.ROOT);
                        if (test.equals(website)) {
                            count++;
                        }
                    }
                    if (count == 0) {
                        Boolean checkinsertdata = dBhelper.insertuserdata(website, passs);
                        if (checkinsertdata == true) {

                            Toast.makeText(random.this, "new Entry Inserted", Toast.LENGTH_SHORT).show();
                            Toast.makeText(random.this, "Website " + website + " PAssword is " + passs, Toast.LENGTH_SHORT).show();

                        } else
                            Toast.makeText(random.this, "new entry not inserted", Toast.LENGTH_SHORT).show();

                    }
                    else
                        Toast.makeText(random.this, "Website already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenufromrandom,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.hom)
        {
            Intent homm=new Intent(random.this,MainActivity.class);
            startActivity(homm);
        }
        if(id==R.id.creat)
        {
            Intent gen=new Intent(random.this,createurownn.class);
            startActivity(gen);
        }
        if(id==R.id.retreiv)
        {
            ret=new Intent(random.this,retreivepass.class);
            startActivity(ret);
        }
        if(id==R.id.delet)
        {
            del=new Intent(random.this,deletepass.class);
            startActivity(del);
        }
        if(id==R.id.updat)
        {
            Intent upda=new Intent(random.this,updatepass.class);
            startActivity(upda);
        }
        if(id==R.id.viewa) {
            Intent vie=new Intent(random.this,viewallpass.class);
            startActivity(vie);
        }
        return super.onOptionsItemSelected(item);
    }
}