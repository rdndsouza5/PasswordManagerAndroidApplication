package com.example.passwordmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class createurownn extends AppCompatActivity {
    Button save;
    EditText webb,passs;
    Intent homm,ran,del,ret,urown;
    DBhelper dBhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createurownn);
        save=findViewById(R.id.save);
        webb=findViewById(R.id.webb);
        passs=findViewById(R.id.passs);
        dBhelper=new DBhelper(this);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count=0;
                String website=webb.getText().toString().toLowerCase(Locale.ROOT);
                String passw =passs.getText().toString();

                if(webb.getText().toString().equals("")||passs.getText().toString().equals(""))
                    Toast.makeText(createurownn.this    , "Please enter both the details", Toast.LENGTH_SHORT).show();
                else {
                    Cursor res = dBhelper.getdata();
                    if (res.getCount()==0){
                    }
                    while (res.moveToNext()) {
                        String test = res.getString(0).toLowerCase(Locale.ROOT);
                        if (test.equals(website)) {
                            count++;
                        }
                    }
                   if(count==0) {


                       Boolean checkinsertdata = dBhelper.insertuserdata(website, passw);
                       if (checkinsertdata == true) {

                           String websit, pas;
                           websit = webb.getText().toString();
                           Toast.makeText(createurownn.this, "Website is " + websit + "  Password is " + passw, Toast.LENGTH_SHORT).show();

                       } else
                           Toast.makeText(createurownn.this, "new entry not inserted", Toast.LENGTH_SHORT).show();

                   }
                   else
                       Toast.makeText(createurownn.this, "Website already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenuforurown,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.rando) {
            ran=new Intent(createurownn.this,random.class);
            startActivity(ran);
        }
            if(id==R.id.hom)
        {
             homm=new Intent(createurownn.this,MainActivity.class);
            startActivity(homm);
        }
            if(id==R.id.retreiv)
            {
                ret=new Intent(createurownn.this,retreivepass.class);
                startActivity(ret);
            }
            if(id==R.id.delet)
            {
                del=new Intent(createurownn.this,deletepass.class);
                startActivity(del);
            }
        if(id==R.id.updat)
        {
            Intent upda=new Intent(createurownn.this,updatepass.class);
            startActivity(upda);
        }
        if(id==R.id.viewa) {
            Intent vie=new Intent(createurownn.this,viewallpass.class);
            startActivity(vie);
        }
        return super.onOptionsItemSelected(item);
    }
}