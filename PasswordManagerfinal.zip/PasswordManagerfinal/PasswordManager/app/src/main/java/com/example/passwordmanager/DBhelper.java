package com.example.passwordmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;

public class DBhelper extends SQLiteOpenHelper {
    private Object LocalDateTime;
    private Object DateTimeException;

    public DBhelper(Context context) {
        super(context, "Password.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Pass(website Text ,password String, created_at DATETIME,is_old varchar(1) ,primary key(website,password))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists Pass");
    }

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public Boolean insertuserdata(String website, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("website", website);
        contentValues.put("password", password);
        contentValues.put("created_at", getDateTime());
        contentValues.put("is_old","n");
        long result = db.insert("pass", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    public Boolean deleteuserdata(String website) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from pass where website = ?", new String[]{website});
        if (cursor.getCount() > 0) {

            long result = db.delete("pass", "website=?", new String[]{website});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdata() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from pass order by created_at ASC ", null);
        return cursor;
    }

    public Boolean deletefirst(String website) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("Select  * from pass where website = ? ORDER BY created_at ASC", new String[]{website});

        if (cursor.getCount() > 0) {
            long result = db.delete("pass", "website=?", new String[]{website});

            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                cursor.moveToNext();
                do {
                    String w = cursor.getString(0);
                    String p = cursor.getString(1);
                    String d = cursor.getString(2);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("website", w);
                    contentValues.put("password", p);
                    contentValues.put("created_at", d);
                    contentValues.put("is_old","y");
                    long r2 = db.insert("pass", null, contentValues);
                } while (cursor.moveToNext());
                if (result == -1) {
                    cursor.moveToFirst();
                    return false;
                } else {
                    cursor.moveToFirst();
                    return true;
                }
            } else {
                cursor.moveToFirst();
                return false;
            }
        }
    return  true;
    }
    public Boolean makeold(String website) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("Select  * from pass where website = ? ORDER BY created_at ASC", new String[]{website});

        if (cursor.getCount() > 0) {
            long result = db.delete("pass", "website=?", new String[]{website});

            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                do {
                    String w = cursor.getString(0);
                    String p = cursor.getString(1);
                    String d = cursor.getString(2);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("website", w);
                    contentValues.put("password", p);
                    contentValues.put("created_at", d);
                    contentValues.put("is_old","y");
                    long r2 = db.insert("pass", null, contentValues);
                } while (cursor.moveToNext());
                if (result == -1) {
                    cursor.moveToFirst();
                    return false;
                } else {
                    cursor.moveToFirst();
                    return true;
                }
            } else {
                cursor.moveToFirst();
                return false;
            }
        }
        return  true;
    }
}